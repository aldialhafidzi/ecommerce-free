<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['full_tag_open'] = "<ul class='pagination flex-m flex-w p-t-26'>";
$config['full_tag_close'] = '</ul>';
$config['num_tag_open'] = '<li class="item-pagination flex-c-m trans-0-4 ">';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = '<li class="item-pagination flex-c-m trans-0-4 active-pagination"><a href="#">';
$config['cur_tag_close'] = '</a></li>';
$config['prev_tag_open'] = '<li class="item-pagination flex-c-m trans-0-4 ">';
$config['prev_tag_close'] = '</li>';

$config['prev_link'] = '< ';
$config['prev_tag_open'] = '<li class="item-pagination flex-c-m trans-0-4 ">';
$config['prev_tag_close'] = '</li>';

$config['next_link'] = ' >';
$config['next_tag_open'] = '<li class="item-pagination flex-c-m trans-0-4 ">';
$config['next_tag_close'] = '</li>';
