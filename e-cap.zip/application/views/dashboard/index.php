<div id="container_table_merek" class="container margin-transaksi" style="min-height : 480px;">
           	<div class="">
           		<div class="">
                 <div class="row ">

                   <!-- <div class="col-sm-12">
                     <nav aria-label="breadcrumb">
                       <ol class="breadcrumb" >
                         <li class="breadcrumb-item"><a href="#">
                           <i class="fas fa-cubes"></i>&nbsp;&nbsp;Master&nbsp;</a>
                         </li>
                       </ol>
                     </nav>
                   </div> -->

                   <!-- <div class="col-sm-12">
                     <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
                       <div class="btn-group btn-group-sm" role="group" aria-label="Two group" >
                         <button name="add_merek" id="add_merek" type="button" class="btn btn-info tambah_data_merek" data-toggle="modal" data-target="#add_dataMerek">
                           <span class="glyphicon glyphicon-plus" aria-hidden="true"></span>&nbsp;Tambah
                         </button>
                         <button name="btn_tambahCombo" id="btn_tambahCombo" type="button" class="btn btn-success btn-sm tambah_data_barang" data-toggle="modal" data-target="#add_dataCombo">
                              <i class="fas fa-file-excel"></i>&nbsp;&nbsp; Export &nbsp;
                         </button>
                         <button name="btn_tambahCombo" id="btn_tambahCombo" type="button" class="btn btn-warning btn-sm tambah_data_barang" data-toggle="modal" data-target="#add_dataCombo">
                              <i class="fas fa-upload"></i>&nbsp;&nbsp; Upload &nbsp;
                         </button>
                       </div>
                     </div>
                   </div> -->

                   <!-- <div class="col-sm-12">
                     <hr>
                   </div> -->
                   <div class="col-sm-6">
                     <div class="row p-l-10 p-b-10 box-admin">
                       <div class="col-sm-12">

                         <a href="<?= base_url() ?>pendingpayment">
                           <div class="col-sm-12" style="background-color : rgb(15, 131, 237); min-height:250px; border-radius: 7px;">

                             <div class="row p-t-30 p-l-30">
                               <div class="col-sm-12">
                                 <h2 style="color : rgb(235, 235, 235);"><i class="fas fa-money-bill-alt"></i> Transaction</h2>
                               </div>

                               <div class="col-sm-12" align="right">
                                 <img src="<?= base_url(); ?>public/images/icons/salam.png" class="image_thumb" alt="Cinque Terre" width="150" height="150">
                                 <h1 style="color : rgb(235, 235, 235);"></h1>
                               </div>
                             </div>

                           </div>
                         </a>
                       </div>

                     </div>
                   </div>

                   <div class="col-sm-6">
                     <div class="row p-l-10 p-b-10 p-r-10 box-admin">
                       <div class="col-sm-12">

                         <a href="<?= base_url() ?>master">
                           <div class="col-sm-12" style="background-color : rgb(6, 97, 193); min-height:250px; border-radius: 7px;">

                             <div class="row p-t-30 p-l-30">
                               <div class="col-sm-12">
                                 <h2 style="color : rgb(235, 235, 235);"> <i class="fas fa-cube"></i> Master</h2>
                               </div>
                               <div class="col-sm-12" align="right">
                                 <img src="<?= base_url(); ?>public/images/icons/hat.png" class="image_thumb" alt="Cinque Terre" width="150" height="150">
                               </div>
                             </div>

                           </div>
                         </a>
                       </div>

                     </div>
                   </div>

                   <div class="col-sm-6">
                     <div class="row p-l-10 p-b-10 box-admin">
                       <div class="col-sm-12">
                         <a href="<?= base_url() ?>admin/listuser">
                           <div class="col-sm-12" style="background-color : rgba(22, 103, 210, 1); min-height:250px; border-radius: 7px;">
                             <div class="row p-t-30 p-l-30">
                               <div class="col-sm-12">
                                 <h2 style="color : rgb(235, 235, 235);"><i class="fas fa-users"></i> Manage User</h2>
                               </div>
                               <div class="col-sm-12" align="right">
                                 <img src="<?= base_url(); ?>public/images/icons/sett.png" class="image_thumb" alt="Cinque Terre" width="150" height="150">
                               </div>
                             </div>
                           </div>
                         </a>

                       </div>

                     </div>
                   </div>

                   <div class="col-sm-6">
                     <div class="row p-l-10 p-r-10 box-admin">
                       <div class="col-sm-12">

                         <a href="<?= base_url() ?>">
                           <div class="col-sm-12" style="background-color : rgb(15, 97, 237); min-height:250px; border-radius: 7px;">
                             <div class="row p-t-30 p-l-30">
                               <div class="col-sm-12">
                                 <h2 style="color : rgb(235, 235, 235);"><i class="fas fa-globe"></i> Website</h2>
                               </div>
                               <div class="col-sm-12" align="right">
                                 <img src="<?= base_url(); ?>public/images/icons/sett.png" class="image_thumb" alt="Cinque Terre" width="150" height="150">
                               </div>
                             </div>
                           </div>
                         </a>
                       </div>

                     </div>
                   </div>



                </div>
              </div>
            </div>
          </div>
